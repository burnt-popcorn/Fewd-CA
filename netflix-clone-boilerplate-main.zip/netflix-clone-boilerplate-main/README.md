# netflix-clone-boilerplate

## Here is the expected output

![](https://github.com/Kalvium-Program/netflix-clone-boilerplate/blob/main/assets/Netflix%20Web%20UI.png?raw=true)

Fork this repo and get started with the cloning project.

## Additional details:
Use color picker extensions link [colorpick-eyedropper](https://chrome.google.com/webstore/detail/colorpick-eyedropper/) in Google chrome to get the exact colors used in the webpage.

The font used: Roboto & Nunito Sans


If you need more icons you can visit [flaticons.com](https://www.flaticon.com/)
